const express = require('express');
const app = express();
const baseUrl = '/stocks/api/v1.0/';
const { validateJsonRequest, createStockObject } = require('../validateFunctionality/validateRequest');
const bodyParser = require('body-parser');

app.use(bodyParser.json());

const {getStock, createStock, updateStock, deleteStock} = require('../database/databaseFunctions');
/**
 * This endpoint will create a stock.  It will accept a ticker value as a query parameter which will be the
 * ticker value stored in the database, and it will accept the rest of the stock as JSON body sent with the request.
 *
 */
app.post(baseUrl + 'createStock/:stockTicker', async function (request, response) {
    var stockToCreate = request.body;
    const stockTicker = request.params.stockTicker;
    try {
        const isValidCrete = await validateJsonRequest(stockToCreate);
        const parsedStock = createStockObject(stockTicker, stockToCreate);
        if(!isValidCrete){
            throw new Error("Bad Request");
        }
        const stockCreated =  await createStock(parsedStock);
        console.log(stockCreated);
        response.send(JSON.stringify(stockCreated));
    }
    catch(err){
        if(err.message === "Bad Request"){
            response.sendStatus(400);
        }
        console.log(err);
        response.sendStatus(404);

    }
    }
);

/**
 * This endpoint will get a stock based on the ticker value which is passed into the query parameter.
 */
app.get(baseUrl + 'getStock/:stockTicker', async function (request, response) {
    const stockTicker = request.params.stockTicker;
    const mongoFilterValue = {"Ticker" : stockTicker};
    try{
    const databaseResults = await getStock(mongoFilterValue);
    response.send(databaseResults);
    }
    catch(err){
        response.sendStatus(400);
    }
});

/**
 * this endpoint will delete a stock basedo n the ticker value which is passed in.
 */
app.delete(baseUrl + 'deleteStock/:stockTicker', async function (request, response) {
    const stockTicker = request.params.stockTicker;
    try {
        const mongoFilterValue = {"Ticker": stockTicker};
        response.send(await deleteStock(mongoFilterValue));
    }
    catch(err){
        response.sendStatus(400);
    }
});

/**
 * This endpoint will update a stock given a ticker included in the URL parameter, with the JSON values included in
 * the body of the request
 */
app.put(baseUrl+'updateStock/:stockTicker', async function (request, response) {
    var stockToUpdate = request.body;
    try {
        const stockTicker = request.params.stockTicker;
        const isValidRequest = validateJsonRequest(stockToUpdate);
        const parsedStock = createStockObject(stockTicker, stockToUpdate);
        if(!isValidRequest){
            throw new error("Bad Request");
        }
        const stockUpdateFunction = {$set: parsedStock};
        const mongoFilterValue = {"Ticker": stockTicker};
        const stockUpdated = await updateStock(mongoFilterValue, stockUpdateFunction);
        response.send(stockUpdated);
    }
    catch(err){
        if(err.message === "Bad Request"){
            response.sendStatus(404);
        }
        response.sendStatus(400);
    }
});


var server = app.listen(8080, function () {
    var host = "localhost";
    var port = server.address().port;
    console.log("Example app listening at http://%s:%s", host, port);
});
