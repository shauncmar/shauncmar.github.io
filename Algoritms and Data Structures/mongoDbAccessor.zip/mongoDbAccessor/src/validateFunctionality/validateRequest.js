class validateRequest{

    /***
     * a constructor for a validate request
     */
    constructor(){
    }

    /**
     * this function will test to see if the received json is valid.
     * @param stockToValidate - should be a json object.
     * @returns {Promise.<void>}
     */
    static async validateJsonRequest(stockToValidate){

        console.log(JSON.stringify(stockToValidate));
        return JSON.parse(JSON.stringify(stockToValidate));
    };

    /**
     * returns a stock object to be created or updated inside of the mongoDb.  This will prevent arbitrary fields form being addded to the
     * database.
     * @param stockTicker accepts the stock ticker to be used
     * @param rawStockObject accepts the raw stock objects from the API
     * @returns {Promise.<{Ticker: *, 50-Day High: *, 20-Day Simple Moving Average: *, Relative Volume: *, Dividend Yield: *, Average Volume: *, Performance (Half Year): *, 52-Week Low: *, 50-Day Simple Moving Average: *, 50-Day Low: *, Company: *, 200-Day Simple Moving Average: *, Gap: *, Volume: *, Performance (Year): number, Relative Strength Index (14): number, Change: number, Change from Open: number, Performance (Quarter): number, Country: string, Industry: string, Performance (YTD): number, 52-Week High: number, Volatility (Week): number, Average True Range: number, Sector: string, Volatility (Month): number, Performance (Month): number, Performance (Week): number, Price: number}>}
     */
    static async createStockObject(stockTicker, rawStockObject){
        return {
            "Ticker": stockTicker,
            "50-Day High" : rawStockObject["50-Day High"],
            "20-Day Simple Moving Average" :rawStockObject["20-Day Simple Moving Average"],
            "Relative Volume" : rawStockObject["Relative Volume"],
            "Dividend Yield" : rawStockObject["Dividend Yield"],
            "Average Volume" : rawStockObject["Average Volume"],
            "Performance (Half Year)" : rawStockObject["Performance (Half Year)"],
            "52-Week Low" :rawStockObject["52-Week Low"],
            "50-Day Simple Moving Average" : rawStockObject["50-Day Simple Moving Average"],
            "50-Day Low" : rawStockObject["50-Day Low"],
            "Company" : rawStockObject["Company"],
            "200-Day Simple Moving Average" : rawStockObject["200-Day Simple Moving Average"],
            "Gap" : rawStockObject["Gap"],
            "Volume" : rawStockObject["Volume"],
            "Performance (Year)" : rawStockObject["Performance (Year)"],
            "Relative Strength Index (14)" : rawStockObject[ "Relative Strength Index (14)"],
            "Change" : rawStockObject["Change"],
            "Change from Open" : rawStockObject["Change from Open"],
            "Performance (Quarter)" : rawStockObject["Performance (Quarter)"],
            "Country" : rawStockObject["Country"],
            "Industry" : rawStockObject["Industry"],
            "Performance (YTD)" : rawStockObject["Performance (YTD)"],
            "52-Week High" : rawStockObject["52-Week High"],
            "Volatility (Week)" : rawStockObject["Volatility (Week)"],
            "Average True Range" : rawStockObject["Average True Range"],
            "Sector" : rawStockObject["Sector"],
            "Volatility (Month)" : rawStockObject["Volatility (Month)"],
            "Performance (Month)" : rawStockObject["Performance (Month)"],
            "Performance (Week)" : rawStockObject["Performance (Week)"],
            "Price" : rawStockObject["Price"]
        }
    }

}

module.exports = validateRequest;