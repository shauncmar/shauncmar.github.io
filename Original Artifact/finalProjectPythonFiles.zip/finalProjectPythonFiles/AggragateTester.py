from FinalProjectMongoDBAccessor import aggrigateStatement
import logging
import json
from bson import json_util
import os

if __name__ == '__main__':
    consoleInput = raw_input("Please enter the sector you would like to aggrigate, type exit to quit \n")
    while(consoleInput != "exit"):
        try:
            logging.warn("input received %s\n" % consoleInput)
            results = aggrigateStatement(consoleInput)
            logging.warn("The results are %s\n" % list(results))
        except:
            logging.error("An error occured with the input, please try again.")
        consoleInput = raw_input("Please enter the sector you would like to aggrigate, type exit to quit \n")
