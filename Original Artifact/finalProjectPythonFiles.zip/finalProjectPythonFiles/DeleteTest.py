from FinalProjectMongoDBAccessor import delete_document
import logging
import json
from bson import json_util
import os

if __name__ == '__main__':
    consoleInput = raw_input("Supply the ticker of the item you would like to delete, type exit to quit \n")
    while(consoleInput != "exit"):
        try:
            logging.warn("input received %s\n" % consoleInput)
            itemToDelete = consoleInput
            result = delete_document(itemToDelete)
            logging.warn("The results from the delete are %s" % result)
        except:
            logging.error("An error occured with the input, please try again.")
        consoleInput = raw_input("Supply the ticker of the item you would like to delete, type exit to quit \n")
