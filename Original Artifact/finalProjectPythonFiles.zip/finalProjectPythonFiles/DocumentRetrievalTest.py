from FinalProjectMongoDBAccessor import running_Average
from FinalProjectMongoDBAccessor import industry_Ticker
import logging
import json
from bson import json_util
import os

if __name__ == '__main__':
    consoleInput = raw_input("Please enter Industry or Average to recieve data about a topic, type exit to quit \n")
    while(consoleInput != "exit"):
        try:
            logging.warn("input received %s\n" % consoleInput)
            if consoleInput == "Industry":
                industryInput = raw_input("Enter the industry you would like to get ticker symbols for \n")
                industryResult = industry_Ticker(industryInput)
                logging.warn("all tickers from %s industry will be displayed" % industryInput)
                logging.warn("Tickers %s" % list(industryResult))
            elif consoleInput == "Average":
                lowValue = raw_input("Please provide the low value of the 50 day average\n")
                highValue = raw_input("Please provide the high value of the 50 day average\n")
                logging.warn("The 50 day average will be displayed between %s and %s" % (lowValue, highValue))
                result = running_Average(float(lowValue), float(highValue))
                logging.warn("The number of documents within the low value %s and high value %s was %s" % (lowValue, highValue, result))
            else:
                logging.warn("Please provide either Industry or Average to receive stats")

        except:
            logging.error("An error occured with the input, please try again.")
        consoleInput = raw_input("Please enter Industry or Average to recieve data about a topic, type exit to quit \n")
