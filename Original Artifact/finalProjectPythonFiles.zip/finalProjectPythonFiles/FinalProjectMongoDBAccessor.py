import json
from bson import json_util
from pymongo import MongoClient
import logging


connection = MongoClient('localhost', 27017)
db = connection['market']
collection = db['stocks']

def create_document(document):
    try:
        if document:
            logging.warn("adding document now %s" % document)
            result = collection.save(document)
        else:
            result = "No document provided"
    except ValueError as ve:
        logging.error(str(ve))
        result = ve
    return result

def read_document(documentId):
    logging.warn("attempting to read document %s" % documentId)
    logging.warn("using db %s" % db.name)
    logging.warn("using collection %s" % collection.name)
    try:
        result = collection.find_one(documentId)
    except ValueError as ve:
        logging.error(str(ve))
        result = ve
    return result
def update_document(documentId, updateParams):
    logging.warn("updating doucment %s with parameters %s" % (documentId, updateParams))
    logging.warn("inside of Update document")
    logging.warn("using db %s" % db.name)
    logging.warn("using collection %s" % collection.name)
    ticker = json.loads("{\"Ticker\": \"%s\"}" % documentId)
    if updateParams > 0:
        volume = json.loads("{\"$set\": {\"Volume\" : \"%s\"}}" % updateParams)
        try:
            result = collection.find_one_and_update(ticker, volume)
        except ValueError as ve:
            logging.error(str(ve))
            result = ve
        return result
    else:
        return "Volume supplied was not greater than 0"

def update_Stock_Document(documentId, updateParams):
    logging.warn("updating doucment %s with parameters %s" % (documentId, updateParams))
    logging.warn("inside of Update document")
    logging.warn("using db %s" % db.name)
    logging.warn("using collection %s" % collection.name)
    ticker = json.loads("{\"Ticker\": \"%s\"}" % documentId)
    if updateParams > 0:
        volume = updateParams
        try:
            result = collection.find_one_and_update(ticker, volume)
        except ValueError as ve:
            logging.error(str(ve))
            result = ve
        return result
    else:
        return "Volume supplied was not greater than 0"

def delete_document(documentId):
    logging.warn("inside of delete")
    logging.warn("using db %s" % db.name)
    logging.warn("using collection %s" % collection.name)
    try:
        ticker = json.loads("{\"Ticker\" : \"%s\"}" % documentId)
        result = collection.find_one_and_delete(ticker)
    except ValueError as ve:
        logging.error(str(ve))
        result = ve
    return result

def running_Average(lowValue, highValue):
    logging.warn("Evaluating the running average between a low of: %s and a high of : %s\n" % (lowValue, highValue))
    logging.warn("using db %s" % db.name)
    logging.warn("using collection %s" % collection.name)
    try:
        query = json.loads("{\"50-Day Simple Moving Average\" : {\"$gt\" : %f, \"$lt\" : %f}}" % (lowValue, highValue))
        rawResutls = collection.find(query)
        result = rawResutls.count()
    except ValueError as ve:
        logging.error(str(ve))
        result = ve
    return result

def industry_Ticker(industry):
    try:
        query = {"Industry": industry}
        logging.warn("The query is %s" % query)
        result = collection.find(query, {"Ticker" : 1})
    except ValueError as ve:
        logging.error(str(ve))
        result = ve
    return result

def industry_Ticker_With_Limit(industry):
    try:
        query = {"Industry" : industry}
        logging.warn("the query is %s" % query)
        result = collection.find(query, {"Ticker" : 1, "Performance (YTD)" : 1}).sort("Performance (YTD)", -1).limit(5)
    except ValueError as ve:
        logging.error(str(ve))
        result = ve
    return result

def aggrigateStatement(sector):
    try:
        matchQuery = json.loads("{\"$match\" : {\"Sector\": \"%s\"}}" % sector)
        groupQuery = {"$group" : {"_id" : "$Industry", "Outstanding Shares" : {"$sum" : "$Shares Outstanding"}}}
        results = collection.aggregate([matchQuery, groupQuery])
    except ValueError as ve:
        logging.error(str(ve))
        results = ve
    return results
