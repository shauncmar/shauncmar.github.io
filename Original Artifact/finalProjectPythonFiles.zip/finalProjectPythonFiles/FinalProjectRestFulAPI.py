import json
from bson import json_util
import logging
import bottle
from bottle import route, run, request, abort
from FinalProjectMongoDBAccessor import create_document
from FinalProjectMongoDBAccessor import read_document
from FinalProjectMongoDBAccessor import update_Stock_Document
from FinalProjectMongoDBAccessor import delete_document
from FinalProjectMongoDBAccessor import industry_Ticker_With_Limit
q

@route('/stocks/api/v1.0/createStock/<tickerSymbol>', method='POST')
def createItem(tickerSymbol):
    data = request.body.readline()
    request.params
    jsonData = json.loads(data)
    jsonData.update({"Ticker" : tickerSymbol})
    if not data:
        abort(404, "no data provided for update")
    try:
        response = create_document(jsonData)
    except:
        abort(404, "dcoument not found")
    if not response:
        abort(404, "document was not found")
    return "Item Created %s \n" % response

@route('/stocks/api/v1.0/getStock/<tickerSymbol>', method='GET')
def readItem(tickerSymbol):
    try:
        itemRead = read_document({"Ticker" : tickerSymbol})
    except:
        abort(404, "Item not found")
    if not itemRead:
        abort(404, "Item not found")
    return json.loads(json.dumps(itemRead, indent=4, default=json_util.default))

@route('/stocks/api/v1.0/updateStock/<tickerSymbol>', method='PUT')
def updateItem(tickerSymbol):
    data = request.body.readline()
    jsonData = json.loads(data)
    try:
        result = update_Stock_Document({"id": tickerSymbol}, {"$set": jsonData})
    except:
        abort(404, "no document to updated")
    return json.loads(json.dumps(result, indent=4, default=json_util.default))

@route('/stocks/api/v1.0/deleteStock/<tickerSymbol>', method='DELETE')
def deleteItem(tickerSymbol):
    try:
        result = delete_document(tickerSymbol)
    except:
        abort(404, "No item was found to be deleted")
    if not result:
        abort(404, "No result for the deleted it")
    return "Item with id %s was deleted with result %s" % (tickerSymbol, result)

@route('/stocks/api/v1.0/industryReport/<industry>', metohd='GET')
def getIndustryReport(industry):
    try:
        result = industry_Ticker_With_Limit(industry)
        logging.warn("the results are %s" % list(result))
    except:
        abort(404, "not implemented")
    return list(result)


@route('/stocks/api/v1.0/stockReport', method='POST')
def getStockReport():
    data = request.json
    stats = []
    try:
        for tickerSymbol in data["list"]:
            logging.warn("geting Data for %s" % json.dumps(tickerSymbol))
            results = read_document({"Ticker" : tickerSymbol})
            logging.warn("The results are %s" % results)
            if results != None:
                stats.append(results)
    except:
        abort(404, "An error occured")
    return json.dumps(stats, indent=4, default=json_util.default)

if __name__ == '__main__':
    # app.run(debug = true)
    run(host='localhost', port=8080)

