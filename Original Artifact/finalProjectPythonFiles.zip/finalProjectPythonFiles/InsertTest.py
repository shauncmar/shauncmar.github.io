from FinalProjectMongoDBAccessor import create_document
import logging
import json
from bson import json_util
import os

if __name__ == '__main__':
    consoleInput = raw_input("enter an object or point to a path, type exit to quit \n")
    while(consoleInput != "exit"):
        try:
            logging.warn("input received %s\n" % consoleInput)
            if consoleInput.startswith("{"):
                logging.warn("input appears to be a json object, we will write directly to the database with %s" % consoleInput)
                jsonInput = json.loads(consoleInput)
                logging.warn("Proccessing JSON object")
                create_document(jsonInput)
            else:
                logging.warn("We will be attempting to read a file %s" % consoleInput)
                fileOpen = open(consoleInput)
                jsonInput = json.load(fileOpen)
                create_document(jsonInput)
        except:
            logging.error("An error occured with the input, please try again.")
        consoleInput = raw_input("enter an object or point to a path, type exit to quit \n")
