from FinalProjectMongoDBAccessor import read_document
import logging
import json
from bson import json_util
import os

if __name__ == '__main__':
    consoleInput = raw_input("Enter the item you would like to lookup, type exit to quit \n")
    while(consoleInput != "exit"):
        try:
            logging.warn("input received %s\n" % consoleInput)
            jsonInput = json.loads(consoleInput)
            document = read_document(jsonInput)
            logging.warn("The Document read is %s" % document)
        except:
            logging.error("An error occured with the input, please try again.")
        consoleInput = raw_input("Enter the item you would like to lookup, type exit to quit \n")
