from FinalProjectMongoDBAccessor import update_document
import logging
import json
from bson import json_util
import os

if __name__ == '__main__':
    consoleInputTicker = raw_input("provide a ticker to update, type exit to quit \n")
    while(consoleInputTicker != "exit"):
        consoleInputVolume = raw_input("provide a volume value to assign.\n")
        try:
            logging.warn("input received %s\n" % consoleInputTicker)
            logging.warn("The volume to be updated %s" % consoleInputVolume)
            results = update_document(consoleInputTicker, consoleInputVolume)
            logging.warn("The resulting document updated is %s" % results)
        except:
            logging.error("An error occured with the input, please try again.")
        consoleInput = raw_input("provide a ticker to update, type exit to quit \n")
