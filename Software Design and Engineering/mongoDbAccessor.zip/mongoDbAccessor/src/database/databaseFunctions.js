const MongoClient = require('mongodb').MongoClient;
const mongoDbDatabaseName = "market";
const mongoDbURL = "mongodb://localhost:27017";

class databaseFunctions {
    /***
     * @constructor
     */
    constructor(){

    }
    /***
     * The getStock function will read a stock from the mongoDb.
     * @param stockTicker - the ticker value of a stock to be looked up in the mongoDb
     * @returns {*} This will return the stock if it is found.
     */
    static async getStock(stockTicker) {
        await new Promise((resolve, reject) => {
            return MongoClient.connect(mongoDbURL, function (err, client) {
                if(err) {
                    reject("there was an error connecting to the database")
                }
                const db = client.db(mongoDbDatabaseName);
                const collection = db.collection('stocks');
                return collection.findOne(stockTicker, function (error, itemFound) {
                    console.log(itemFound);
                    resolve(itemFound);
                });
            });
        })

    }
    /***
     * The updateStock function will update a stock with the given parameters in the mongoDB
     * @param stockTicker
     * @param updateParamters
     * @returns {*}
     */
    static async updateStock(stockTicker, updateParamters){
        await new Promise((resolve, reject) => {
            return MongoClient.connect(mongoDbURL, function (err, client) {
                if(err) {
                    reject("there was an error connecting to the database")
                }
                const db = client.db(mongoDbDatabaseName);
                const collection = db.collection('stocks');
                return collection.findOneAndUpdate(stockTicker, updateParamters)
                    .then((item) => {
                        console.log(item);
                        resolve(item);
                    })
            });
        });
    }

    /***
     *
     * the create stock function will create a stock within the mongoDb.  It will return details about that stock
     * @param validStockObject - this is a valid stock object in JSON form.
     * @returns {*}
     */
    static async createStock(validStockObject){
        await new Promise((resolve, reject) => {
            return MongoClient.connect(mongoDbURL, function (err, client) {
                if(err) {
                    reject("there was an error connecting to the database")
                }
                const db = client.db(mongoDbDatabaseName);
                const collection = db.collection('stocks');
                return collection.insertOne(validStockObject, function (error, itemInserted) {
                    console.log(itemInserted);
                    resolve(itemInserted);
                });
            });
        })
    }

    /***
     * this will remove a stock from the mongoDB given a stock ticker
     * @param stockTicker - a stock ticker that may or may not exist in the mongoDb
     * @returns {*}
     */
    static async deleteStock(stockTicker){
        await new Promise((resolve, reject) => {
            return MongoClient.connect(mongoDbURL, function (err, client) {
                if(err) {
                    reject("there was an error connecting to the database")
                }
                const db = client.db(mongoDbDatabaseName);
                const collection = db.collection('stocks');
                return collection.deleteOne(stockTicker)
                    .then((item) => {
                        console.log(item);
                        resolve(item);
                    })
            });
        })
    }

}

module.exports = databaseFunctions;