const express = require('express');
const app = express();
const baseUrl = '/stocks/api/v1.0/';
const bodyParser = require('body-parser');

app.use(bodyParser.json());

const {getStock, createStock, updateStock, deleteStock} = require('../database/databaseFunctions');
/**
 * This endpoint will create a stock.  It will accept a ticker value as a query parameter which will be the
 * ticker value stored in the database, and it will accept the rest of the stock as JSON body sent with the request.
 *
 */
app.post(baseUrl + 'createStock/:stockTicker', function (request, response) {
    var stockToCreate = request.body;
    const stockTicker = request.params.stockTicker;
    stockToCreate.Ticker = stockTicker;
    const stockCreated = createStock(stockToCreate);
    response.send(stockCreated);
    }
);

/**
 * This endpoint will get a stock based on the ticker value which is passed into the query parameter.
 */
app.get(baseUrl + 'getStock/:stockTicker', function (request, response) {
    const stockTicker = request.params.stockTicker;
    const mongoFilterValue = {"Ticker" : stockTicker};
    const databaseResults = getStock(mongoFilterValue);
    response.send(databaseResults);
});

/**
 * this endpoint will delete a stock basedo n the ticker value which is passed in.
 */
app.delete(baseUrl + 'deleteStock/:stockTicker', function (request, response) {
    const stockTicker = request.params.stockTicker;
    const mongoFilterValue = {"Ticker" : stockTicker};
    response.send(deleteStock(mongoFilterValue));
});

/**
 * This endpoint will update a stock given a ticker included in the URL parameter, with the JSON values included in
 * the body of the request
 */
app.put(baseUrl+'updateStock/:stockTicker', function (request, response) {
    var stockToUpdate = request.body;
    const stockTicker = request.params.stockTicker;
    const stockUpdateFunction  = {$set: stockToUpdate}
    const mongoFilterValue = {"Ticker" : stockTicker};
    const stockUpdated = updateStock(mongoFilterValue, stockUpdateFunction);
    response.send(stockUpdated);
});


var server = app.listen(8080, function () {
    var host = "localhost";
    var port = server.address().port;
    console.log("Example app listening at http://%s:%s", host, port);
});
